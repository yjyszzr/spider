import os
import time

while True:
    os.system('python3 league.py')
    print('更新完毕,休息十分钟')
    time.sleep(600)
