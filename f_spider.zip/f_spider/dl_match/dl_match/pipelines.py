# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html
from pymysql import connect
import time

class DlMatchPipeline(object):

    def __init__(self):
        self.db = connect(host='172.17.0.100', port=3306, user='cxm_user_rw', password='YNShTBmL1X1X', database='cxm_lottery',charset='utf8')
        self.cur = self.db.cursor()

    def __del__(self):
        self.cur.close()
        self.db.close()
    def process_item(self, item, spider):
        sq1 = "select * from dl_match where changci_id=%s;"%item['changci_id']
        sq2 = "select * from dl_match_play where changci_id = %s and play_type=%s;"%(item['changci_id'],item['play_type'])
        #dl_match判断是插入还是更新的条件
        cond1 = self.cur.execute(sq1)
        #dl_match_play判断是插入还是更新条件
        if cond1:
            sql = "update dl_match set home_team_rank='{}',visiting_team_rank='{}' where changci_id={}".format(
                item['home_team_rank'], item['visiting_team_rank'], item['changci_id'])
            self.cur.execute(sql)
            self.db.commit()
            print("match成功更新>{}".format(item['changci_id']))
        else:
            sql = "insert into dl_match(league_name,league_addr,changci_id,changci,home_team_id,home_team_name,home_team_abbr,home_team_rank,visiting_team_id,visiting_team_name,visiting_team_abbr,visiting_team_rank,match_time,show_time,is_show,match_sn,create_time) values('{}','{}',{},'{}',{},'{}','{}','{}',{},'{}','{}','{}','{}','{}',{},'{}',{});".format(item['league_name'],item['league_addr'],item['changci_id'],item['changci'],item['home_team_id'],item['home_team_name'],item['home_team_abbr'],item['home_team_rank'],item['visiting_team_id'],item['visiting_team_name'],item['visiting_team_abbr'],item['visiting_team_rank'],item['match_time'],item['show_time'],item['is_show'],item['match_sn'],int(time.time()))
            self.cur.execute(sql)
            self.db.commit()
            print("match成功插入%s"%item['changci_id'])

        cond2 = self.cur.execute(sq2)
        if cond2:
            sql = 'update dl_match_play set play_content="{}",update_time={} where changci_id={} and play_type={};'.format(item['play_content'],int(time.time()),item['changci_id'],item['play_type'])
            self.cur.execute(sql)
            self.db.commit()
            print("match_play成功更新%s--%s"%(item['changci_id'],item['play_type']))
        else:
            sql = 'insert into dl_match_play(changci_id,play_content,play_type,create_time,update_time,status,is_del,is_hot) values({},"{}",{},{},{},{},{},{});'.format(item['changci_id'],item['play_content'],item['play_type'],int(time.time()),int(time.time()),0,0,0)
            self.cur.execute(sql)
            self.db.commit()
            print("match_play成功插入%s--%s"%(item['changci_id'],item['play_type']))
        return item
