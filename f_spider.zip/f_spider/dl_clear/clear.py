import os
import re
import time

while True:
    os.system('python3 clearLog.py')
    print('日志清理完毕,休息一小时')
    time.sleep(3600)