# -*- coding: utf-8 -*-
import os
import time

while True:
    os.system('python future.py')
    print("未来赛事抓取完毕!休息一小时")
    time.sleep(3600)
