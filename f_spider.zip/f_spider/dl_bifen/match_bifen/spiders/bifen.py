# -*- coding: utf-8 -*-
import scrapy
from pymysql import connect
import re
import time
from match_bifen.items import MatchBifenItem


class BifenSpider(scrapy.Spider):
    name = 'bifen'
    allowed_domains = ['sporttery.cn']
    def start_requests(self):
        db = connect(host='172.17.0.100', port=3306, user='cxm_user_rw', password='YNShTBmL1X1X', database='cxm_lottery',
                     charset='utf8')
        cur = db.cursor()
        sql = "select show_time,changci_id from dl_match where status = 0 and TIMESTAMPDIFF(MINUTE, match_time, NOW()) >= 90 and is_show=1;"
        cur.execute(sql)
        dbs = cur.fetchall()
        cur.close()
        db.close()
        for i in dbs:
            match_time, changci_id = i
            d = str(match_time)
            m_time = d.split(' ')[0]
            url = "http://info.sporttery.cn/football/match_result.php?page=1&search_league=0&start_date={}".format(m_time)
            yield  scrapy.Request(url=url,meta={"changci_id":changci_id,"m_time":m_time},dont_filter=True)

    def parse(self, response):
        changci_id = response.meta['changci_id']
        m_time = response.meta['m_time']
        str = response.body.decode('gbk')
        t = re.findall('%s'%changci_id,str)
        if t:
            item = MatchBifenItem()
            com = '<a href="http://info.sporttery.cn/football/info/fb_match_info.php\?m={}".*?<span class="blue">(.*?)</span>.*?<span class="u-org" style="font-weight:bold; font-size:13px;">(.*?)</span>.*?<td width="86">(.*?)</td>'.format(changci_id)
            first_half = re.search(com,str,re.S).group(1)
            whole = re.search(com,str,re.S).group(2)
            status = re.search(com,str,re.S).group(3)
            item['first_half'] = first_half
            item['whole'] = whole
            if status == "已完成":
                item['status'] = "1"
            elif "取消" in status:
               item['status'] = "2"
            item['changci_id'] = changci_id
            yield item
        else:
            page = 1
            p = re.findall('<a href="match_result.php\?page=(\d+).*?target="_self"', str)[-1]
            print(p)
            while page<=int(p):
                url = "http://info.sporttery.cn/football/match_result.php?page={}&search_league=0&start_date={}".format(page,
                    m_time)
                page += 1
                yield scrapy.Request(url=url, callback=self.parse_it,meta={"changci_id": changci_id, "m_time": m_time}, dont_filter=True)
    def parse_it(self,response):
        changci_id = response.meta['changci_id']
        m_time = response.meta['m_time']
        str = response.body.decode('gbk')
        t = re.findall('%d'%changci_id,str)
        print(response.url,changci_id,t)
        if t:
            item = MatchBifenItem()
            com = '<a href="http://info.sporttery.cn/football/info/fb_match_info.php\?m={}".*?<span class="blue">(.*?)</span>.*?<span class="u-org" style="font-weight:bold; font-size:13px;">(.*?)</span>.*?<td width="86">(.*?)</td>'.format(changci_id)
            first_half = re.search(com,str,re.S).group(1)
            whole = re.search(com,str,re.S).group(2)
            status = re.search(com,str,re.S).group(3)
            item['first_half'] = first_half
            item['whole'] = whole
            if status == "已完成":
                item['status'] = "1"
            else:
               item['status'] = "2"
            item['changci_id'] = changci_id

            yield item
